import sys
import time
import math
import hashlib
import os
from datetime import datetime


def cpu_trabalho(segundos):
    inicio = time.perf_counter()
    ciclos = 0

    while time.perf_counter() - inicio < segundos:
        valor = 0.123456789

        for i in range(1, 250_000):
            valor = math.sin(valor + i) * math.cos(valor - i)

        ciclos += 1

        if ciclos % 5 == 0:
            decorrido = time.perf_counter() - inicio
            print(
                f"[{datetime.now():%H:%M:%S}] "
                f"CPU trabalhando | {decorrido:.1f}s decorridos | "
                f"{ciclos} ciclos"
            )


def memoria_controlada(mb=256):
    print(f"[MEMORIA] Alocando aproximadamente {mb} MB...")
    dados = bytearray(mb * 1024 * 1024)

    for i in range(0, len(dados), 4096):
        dados[i] = (i // 4096) % 256

    print("[MEMORIA] Memória alocada e sendo utilizada.")
    return dados


def hash_trabalho(segundos):
    inicio = time.perf_counter()
    contador = 0
    bloco = b"RPA CONTROL ROOM TESTE " * 1024

    while time.perf_counter() - inicio < segundos:
        hashlib.sha256(bloco).digest()
        contador += 1

    print(f"[HASH] {contador:,} hashes executados.")


def main():
    duracao = 120

    if len(sys.argv) > 1:
        try:
            duracao = int(sys.argv[1])
        except ValueError:
            print("Use: python robo_pesado.py 120")
            return

    if duracao <= 0:
        print("A duração precisa ser maior que zero.")
        return

    print("=" * 60)
    print("        ROBO PESADO - TESTE DO CONTROL ROOM")
    print("=" * 60)
    print(f"Início:   {datetime.now():%d/%m/%Y %H:%M:%S}")
    print(f"Duração:  {duracao} segundos")
    print(f"PID:      {os.getpid()}")
    print("=" * 60)

    dados = memoria_controlada(256)
    inicio = time.perf_counter()

    try:
        while time.perf_counter() - inicio < duracao:
            restante = duracao - (time.perf_counter() - inicio)
            bloco = min(10, restante)

            print(f"\n[TESTE] Executando bloco de {bloco:.1f}s...")
            cpu_trabalho(bloco)
            hash_trabalho(min(3, bloco))

            decorrido = time.perf_counter() - inicio
            print(f"[PROGRESSO] {decorrido:.1f}s / {duracao}s")

    finally:
        del dados

    print("\n" + "=" * 60)
    print("ROBO FINALIZADO COM SUCESSO")
    print(f"Fim: {datetime.now():%d/%m/%Y %H:%M:%S}")
    print("=" * 60)


if __name__ == "__main__":
    main()
